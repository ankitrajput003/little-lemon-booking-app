import React, { useState } from 'react';
function BookingForm() {
  const [name, setName] = useState('');
  const handleSubmit = e => {
    e.preventDefault();
    alert(`Booking confirmed for ${name}`);
  };
  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor="name">Name:</label>
      <input id="name" value={name} onChange={e => setName(e.target.value)} />
      <button type="submit">Book</button>
    </form>
  );
}
export default BookingForm;