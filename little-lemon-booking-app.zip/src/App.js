import React from 'react';
import BookingForm from './components/BookingForm';
function App() {
  return <BookingForm />;
}
export default App;