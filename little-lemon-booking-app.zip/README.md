# Little Lemon Booking App

A React app for table reservations.